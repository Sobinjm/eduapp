
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.1.0
    </div>
    <img class="img-responsive" src="<?php echo base_url(); ?>admdist/dist/img/logo.png" style="margin-top: -10px;max-width: 60%;height: 30px;" /> 
 </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>admdist/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>admdist/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url(); ?>admdist/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>admdist/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>admdist/dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url(); ?>admdist/dist/js/datatables.min.js"></script>
<script src="<?php echo base_url(); ?>admdist/dist/js/sweetalert2.min.js"></script>
<script src="<?php echo base_url(); ?>admdist/dist/moment-develop/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>admdist/dist/js/bootstrap-datetimepicker.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>admdist/dist/js/demo.js"></script>
<script src="<?php echo base_url(); ?>admdist/dist/js/toggler.js"></script>
<script src="<?php echo base_url(); ?>admdist/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?php echo base_url(); ?>admdist/plugins/node_modules/video.js/dist/video.min.js"></script>
<script src="<?php echo base_url(); ?>admdist/plugins/ckeditor5/ckeditor.js"></script>
<script>
  $(document).ready(function () {
    $('.sidebar-menu').tree()
  })
</script>
</body>
</html>
