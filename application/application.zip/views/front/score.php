<?php
$data['result']='inserted';
 echo json_encode($data);

?>