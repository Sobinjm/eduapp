<?php
$data['result']='inserted';
 print_r(json_encode($data));

?>