<footer id="footerType2"  class="container">
	
        <div class="blockClass fContainer">
            <div class="container">
                <div class="fContent">
                    <span class="fLogoName">
                        <span class="labelIcon labelIconSmall"></span>
                        <strong style="color: #929292">E-LEARNING</strong> PLATFORM
                    </span>
                    <span>v1.0.0 - October 2018</span>
                </div>
                <div class="fContent">
                    <a href="#">Privacy policy</a> |
                    <a href="#">Terms and conditions</a>
                </div>
            </div>
        </div>
	</footer>
	<!--Footer-->
</body>
</html>