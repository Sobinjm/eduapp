<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lesson extends CI_Controller {

	
	function __construct()
	{
		parent::__construct();
		
		if (!$this->session->has_userdata('logged_in') || $this->session->userdata('logged_in') !== TRUE)
			{ 
				redirect('login');
			}
	}
	
	
	public function index()
	{
		$this->load->view('front/lesson_one');
	}
	
	public function one()
	{
		$this->load->view('front/lesson_one');
	}
	
	public function two()
	{
		$this->load->view('front/lesson_two');
	}
	
	public function three()
	{
		$this->load->view('front/lesson_three');
	}
	
	public function four()
	{
		$this->load->view('front/lesson_four');
	}
	
	public function five()
	{
		$this->load->view('front/lesson_five');
	}
	
	public function six()
	{
		$this->load->view('front/lesson_six');
	}
	
	public function seven()
	{
		$this->load->view('front/lesson_seven');
	}
	
	public function eight()
	{
		$this->load->view('front/lesson_eight');
	}
	
	
	
	
}
