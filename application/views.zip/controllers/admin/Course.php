<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Course extends CI_Controller {

	
	function __construct()
	{
		parent::__construct();
		
		if (!$this->session->has_userdata('logged_in') || $this->session->userdata('logged_in') !== TRUE)
			{ 
				redirect('admin/login');
			}
		$this->load->model('admin/Mcourse', 'mcourse_model');	
	}
	
	
	public function index()
	{
		$data['result'] = $this->mcourse_model->getAllcourse();
		$this->load->view('admin/course', $data);
	}
	
	public function add()
	{	
		$this->form_validation->set_rules('course_name', 'Course name', 'trim|required');
        $this->form_validation->set_rules('no_lessons', 'Number of lessons', 'required');
        if ($this->form_validation->run() == false) 
		{
			echo 'Form validation failed';
        } 
		else
		{
			$course_name 		= $this->security->xss_clean($this->input->post('course_name'));
			$brief_desc 		= $this->security->xss_clean($this->input->post('brief_desc'));
			$no_lessons 		= $this->security->xss_clean($this->input->post('no_lessons'));
			$publish_status 	= $this->security->xss_clean($this->input->post('publish_status'));
			
			if(isset($_FILES['icon_file']))
				{
					$errors		=	array();
					$file_name	=	$_FILES['icon_file']['name'];
					$file_size	=	$_FILES['icon_file']['size'];
					$file_tmp	=	$_FILES['icon_file']['tmp_name'];
					$file_type	=	$_FILES['icon_file']['type'];
					$file_ext	= 	pathinfo($file_name, PATHINFO_EXTENSION);
					
					$expensions	=	array("jpeg","jpg","png","gif");
					  
					if(in_array($file_ext,$expensions)=== false)
						{
							$errors[]="extension not allowed, please choose a JPEG or PNG file.";
						}
					  
					if($file_size > 2097152)
						{
							$errors[]='File size must be less than 2 MB';
						}
					  
					if(empty($errors)==true)
						{
							$target_dir_galry		=	"content/uploads/course/";
							$fileExt_galry			=	pathinfo($file_name, PATHINFO_EXTENSION);
							$randfileName_galry		=	time() . rand() . "." . $fileExt_galry;
							$target_file_galry		=	$target_dir_galry . basename($randfileName_galry);
							$moveResult				=	move_uploaded_file($file_tmp,$target_file_galry);
							if(!$moveResult)
								{
									$response = array(
											'status'  => 'error',
											'message' => 'Icon upload failed'
										);
									echo json_encode($response);
									exit();
								}
							
						}
					else
						{
							$response = array(
											'status'  => 'error',
											'message' => $errors
										);
							echo json_encode($response);
							exit();
						}
				}
				
				$language = array();
				
				if (!empty($_POST['english']) && $this->input->post('english') == 'eng')
					{
						$language['english'] = '1';
					}
				else 
					{
						$language['english'] = '0';
					}
					
				if (!empty($_POST['arabic']) && $this->input->post('arabic') == 'arb')
					{
						$language['arabic'] = '1';
					}
				else 
					{
						$language['arabic'] = '0';
					}	
					
				if (!empty($_POST['urdu']) && $this->input->post('urdu') == 'urd')
					{
						$language['urdu'] = '1';
					}
				else 
					{
						$language['urdu'] = '0';
					}	
				
				if (!empty($_POST['pashto']) && $this->input->post('pashto') == 'pas')
					{
						$language['pashto'] = '1';
					}
				else 
					{
						$language['pashto'] = '0';
					}	
				
				if (!empty($_POST['malayalam']) && $this->input->post('malayalam') == 'mal')
					{
						$language['malayalam'] = '1';
					}
				else 
					{
						$language['malayalam'] = '0';
					}	
				
				
				if($publish_status == 'draft')
					{
						$publish_status = '1';
					}
				else 
					{
						$publish_status = '0';
					}					
				
				$insert_data = array(
								'course_name'	 =>	$course_name,
								'course_lang'	 =>	json_encode($language),
								'icon_file'		 =>	$target_file_galry,
								'course_desc'	 =>	$brief_desc,
								'lesson_no'		 =>	$no_lessons,
								'updated_by'	 =>	$this->crc_encrypt->decode($this->session->userdata('userid')),
								'publish_status' => $publish_status
							);
				$query = $this->mcourse_model->insert_course($insert_data);
				if($query) 
				{		
					$response = array(
											'status'  => 'success',
											'message' => 'Course added successfully'
										);
					echo json_encode($response);
					exit();
				}
				else 
				{
					$response = array(
											'status'  => 'success',
											'message' => 'Sorry, we are not able to add this student now.'
										);
					echo json_encode($response);
					exit();
				}	
		}
	}
	
	public function updatecourse()
	{
			$staff_id = $this->security->xss_clean($this->input->post('id'));
			$staff_name = $this->security->xss_clean($this->input->post('name'));
			$staff_email = $this->security->xss_clean($this->input->post('email'));
			$staff_cnumber = $this->security->xss_clean($this->input->post('staff_number'));
			$staff_password = $this->security->xss_clean($this->input->post('password'));
			
			if(!empty($staff_password))
				{
					$hash_password = password_hash($staff_password, PASSWORD_DEFAULT);
					$id = $this->crc_encrypt->decode($staff_id);
					$update_data = array(
									'name' => $staff_name,
									'email' => $staff_email,
									'password' => $hash_password,
									'contact_number' => $staff_cnumber,
									'role' => '0'
									);
					$query = $this->mstudent_model->update_staff_passwd($id,$update_data);
					if($query) 
						{		
							echo 'Student updated successfully.';
							exit();
						}
					else 
						{
							echo 'Sorry, we are not able to add this student now.';
							exit();
						}					
				}
			else 
				{
					
					$id = $this->crc_encrypt->decode($staff_id);				
					$update_data = array(
									'name' => $staff_name,
									'email' => $staff_email,
									'contact_number' => $staff_cnumber,
									'role' => '0'
									);
					$query = $this->mstudent_model->update_staff($id,$update_data);
					if($query) 
						{		
							echo 'Student updated successfully.';
							exit();
						}
					else 
						{
							echo 'Sorry, we are not able to add this student now.';
							exit();
						}
				}
	}
	
	
	
	public function delete()
		{
			$id = $this->security->xss_clean($this->input->post('id'));
			if(empty($id))
			{
				echo 'Sorry, we are not able to delete this staff now.';	
			}
			else 
			{
				$data = array('id' => $this->crc_encrypt->decode($id));
				$query = $this->mcourse_model->delete_course($data);
				if($query) 
				{		
					echo 'Course deleted successfully.';
				}
				else 
				{
					echo 'Sorry, we are not able to delete this course now.';
				}
			}
			
		}
		
	public function getcoursebyid()
		{
			$id = $this->security->xss_clean($this->input->post('id'));
			if(empty($id))
			{
				echo 'empty_id';	
			}
			else 
			{
				$data = $this->crc_encrypt->decode($id);
				$query = $this->mcourse_model->getCourseid($data);
				if($query)
				{		
					$course_lang = json_decode($query[0]['course_lang']);
					if($course_lang->english == '1')
						{
							$language[] = '<button type="button" class="btn btn-danger btn-xs mr-5px">English</button>';
						}
										
					if($course_lang->arabic == '1')
						{
							$language[] = '<button type="button" class="btn btn-warning btn-xs mr-5px">Arabic</button>';
						}
										
					if($course_lang->urdu == '1')
						{
							$language[] = '<button type="button" class="btn btn-success btn-xs mr-5px">Urdu</button>';
						}
										
					if($course_lang->pashto == '1')
						{
							$language[] = '<button type="button" class="btn btn-primary btn-xs mr-5px">Pashto</button>';
						}
										
					if($course_lang->malayalam == '1')
						{
							$language[] = '<button type="button" class="btn btn-info btn-xs mr-5px">Malayalam</button>';
						}
					
					$html = '<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 border-course">
								<img src="'.base_url().$query[0]['icon_file'].'" class="img-responsive" />
								<p class="txt-center">'.$query[0]['course_name'].'</p>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 border-course">
								<div class="attachment item-colors">
									<h5><strong>Course Name:</strong></h5>
									<p class="filename">
										'.$query[0]['course_name'].'
									</p>
								</div>
								<div class="attachment item-colors">
									<h5><strong>Course Language:</strong></h5>
									<p class="filename">
										'.implode(" ",$language).'
									</p>
								</div>
								<div class="attachment item-colors">
									<h5><strong>Course Description:</strong></h5>
									<p class="filename">
										'.$query[0]['course_desc'].'
									</p>
								</div>
								<div class="attachment item-colors">
									<h5><strong>No. of lessons:</strong></h5>
									<p class="filename">
										'.$query[0]['lesson_no'].'
									</p>
								</div>
							</div>';
					
					$response = array(
								'status'	=> 'success',
								'html'		=> $html			
								);
					echo json_encode($response);
				}
				else 
				{
					$response = array(
								'status'	=> 'error',
								'html'		=> 'Unable to process data'			
								);
					echo json_encode($response);			
				}
			}
			
		}
		
	public function getcourse()
		{
			$id = $this->security->xss_clean($this->input->post('id'));
			if(empty($id))
			{
				echo 'empty_id';	
			}
			else 
			{
				$data = $this->crc_encrypt->decode($id);
				$query = $this->mcourse_model->getCourseid($data);
				if($query)
				{		
					echo json_encode($query);
				}
				else 
				{
					echo 'error';
				}
			}
			
		}	
		
		
		
}
