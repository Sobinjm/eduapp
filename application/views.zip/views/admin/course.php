
  <!-- =============================================== -->
  <?php $this->load->view('admin/header'); ?>
  <!-- Left side column. contains the sidebar -->
  <?php $this->load->view('admin/main_sidebar'); ?>
  <!-- =============================================== -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Course Management
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Course Management</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="box box-danger">
				<div class="box-header with-border">
				  <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
					<h3 class="box-title">All Course Management</h3>
				  </div>
				  <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
					<button type="button" class="btn btn-block btn-danger btn-flat" data-toggle="modal" data-target="#modal-default">Add Course</button>
				  </div> 	
				</div>
				<div class="table_padding">
					<table id="admin_table" class="table table-striped table-bordered" style="width:100%">
						<thead>
							<tr>
								<th>Id</th>
								<th>Course</th>
								<th>Language</th>
								<th>No. of Lessons</th>
								<th>Status</th>
								<th>Created On</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php $i = 1; foreach($result as $adm) { ?>
							<tr>
								<td><?php echo $i; ?></td>
								<td>
									<?php 
										echo '<button type="button" class="btn btn-xs view_courses" data-toggle="modal" data-target="#modal-view" data-id="'.$this->crc_encrypt->encode($adm['id']).'"><i class="fa fa-eye mr-15px"></i>'.$adm['course_name'].'</button>';
									?>
								</td>
								<td>
									<?php 
										$course_lang = json_decode($adm['course_lang']);
										if($course_lang->english == '1')
										{
											echo '<button type="button" class="btn btn-danger btn-xs mr-5px">English</button>';
										}
										
										if($course_lang->arabic == '1')
										{
											echo '<button type="button" class="btn btn-warning btn-xs mr-5px">Arabic</button>';
										}
										
										if($course_lang->urdu == '1')
										{
											echo '<button type="button" class="btn btn-success btn-xs mr-5px">Urdu</button>';
										}
										
										if($course_lang->pashto == '1')
										{
											echo '<button type="button" class="btn btn-primary btn-xs mr-5px">Pashto</button>';
										}
										
										if($course_lang->malayalam == '1')
										{
											echo '<button type="button" class="btn btn-info btn-xs mr-5px">Malayalam</button>';
										}
										
									?>
								</td>
								<td><?php echo $adm['lesson_no']; ?></td>
								<td>
									<?php 
										if($adm['publish_status'] == '0')
										{
											echo '<button type="button" class="btn btn-danger btn-xs">Pending</button>';
										}
										
										if($adm['publish_status'] == '1')
										{
											echo '<button type="button" class="btn btn-warning btn-xs">Draft</button>';
										}
										
										if($adm['publish_status'] == '2')
										{
											echo '<button type="button" class="btn btn-success btn-xs">Published</button>';
										}
									?>
								</td>
								<td><?php echo date('d-m-Y',strtotime($adm['created_on'])); ?></td>
								<td>
								<button class="btn btn-xs btn-success edit_now" data-id="<?php echo $this->crc_encrypt->encode($adm['id']); ?>"><i class="fa fa-edit"></i> Edit</button>
								<button class="btn btn-xs btn-danger delete_now" data-id="<?php echo $this->crc_encrypt->encode($adm['id']); ?>"><i class="fa fa-times"></i> Delete</button>
								</td>
							</tr>
							<?php $i++; } ?>
						</tbody>
						<tfoot>
							<tr>
								<th>Id</th>
								<th>Course</th>
								<th>Language</th>
								<th>No. of Lessons</th>
								<th>Status</th>
								<th>Created On</th>
								<th></th>
							</tr>
						</tfoot>
					</table>
				</div>
			  </div>
			
		</div>
		
		<div class="modal fade in" id="modal-default">
          <div class="modal-dialog modal-md">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Add Course</h4>
              </div>
              <div class="modal-body">
				<form class="form-horizontal" enctype="multipart/form-data" id="add_course_form">
					<div class="form-group">
						<label for="course_name" class="col-sm-4 control-label">Course Name</label>
						<div class="col-sm-8">
							<input type="textbox" class="form-control" id="course_name" name="course_name" placeholder="Course Name">
						</div>
					</div>
					<div class="form-group">
						<label for="course_language" class="col-sm-4 control-label">Course Language</label>
						<div class="col-sm-8">
							<div class="form-group">
									<div class="col-sm-12 pull-right">
										<label class="mr-5">
										  <input type="checkbox" id="english" name="english" value="eng" class="minimal-red" checked> English
										</label>
										
										<label class="mr-5">
										  <input type="checkbox" id="arabic" name="arabic" value="arb" class="minimal-red"> Arabic
										</label>
									
										<label class="mr-5">
										  <input type="checkbox" id="urdu" name="urdu" value="urd" class="minimal-red"> Urdu
										</label>
									</div>
									<div class="col-sm-12 pull-right">
										<label class="mr-5">
										  <input type="checkbox" id="pashto" name="pashto" value="pas" class="minimal-red"> Pashto
										</label>
										
										<label class="mr-5">
										  <input type="checkbox" id="malayalam" name="malayalam" value="mal" class="minimal-red"> Malayalam
										</label>
									
									</div>
									
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="icon_file" class="col-sm-4 control-label">Icon Upload</label>
						<div class="col-sm-8">
							<input type="file" id="icon_file" name="icon_file">
							<small>Only jpg, jpeg, png and gif file types allowed.</small>
						</div>
					</div>
					<div class="form-group">
						<label for="brief_desc" class="col-sm-4 control-label">Brief Desc</label>
						<div class="col-sm-8">
							<textarea id="brief_desc" name="brief_desc" rows="10" style="width:100%">
							
							</textarea>
						</div>
					</div>
					<div class="form-group">
						<label for="no_lessons" class="col-sm-4 control-label">No. of Lessons</label>
						<div class="col-sm-8">
							<input type="textbox" class="form-control" id="no_lessons" name="no_lessons" placeholder="No. of Lessons">
						</div>
					</div>
				</div>
              <div class="modal-footer">
                <button type="button" class="btn btn-flat btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-flat btn-warning save_now" data-action="draft">Save as draft</button>
				<button type="button" class="btn btn-flat btn-success save_now" data-action="publish">Publish now</button>
				</form>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		
		<div class="modal fade in" id="modal-edit">
          <div class="modal-dialog modal-md">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Edit Course</h4>
              </div>
              <div class="modal-body">
				<form class="form-horizontal" enctype="multipart/form-data" id="edit_form">
					<div class="form-group">
						<label for="course_name" class="col-sm-4 control-label">Course Name</label>
						<div class="col-sm-8">
							<input type="textbox" class="form-control" id="edit_course_name" name="edit_course_name" placeholder="Course Name">
						</div>
					</div>
					<div class="form-group">
						<label for="course_language" class="col-sm-4 control-label">Course Language</label>
						<div class="col-sm-8">
							<div class="form-group">
									<div class="col-sm-12 pull-right">
										<label class="mr-5">
										  <input type="checkbox" id="edit_english" name="edit_english" value="eng" class="minimal-red" checked> English
										</label>
										
										<label class="mr-5">
										  <input type="checkbox" id="edit_arabic" name="edit_arabic" value="arb" class="minimal-red"> Arabic
										</label>
									
										<label class="mr-5">
										  <input type="checkbox" id="edit_urdu" name="edit_urdu" value="urd" class="minimal-red"> Urdu
										</label>
									</div>
									<div class="col-sm-12 pull-right">
										<label class="mr-5">
										  <input type="checkbox" id="edit_pashto" name="edit_pashto" value="pas" class="minimal-red"> Pashto
										</label>
										
										<label class="mr-5">
										  <input type="checkbox" id="edit_malayalam" name="edit_malayalam" value="mal" class="minimal-red"> Malayalam
										</label>
									
									</div>
									
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="icon_file" class="col-sm-4 control-label">Icon Upload</label>
						<div class="col-sm-8">
							<input type="file" id="edit_icon_file" name="edit_icon_file">
							<small>Only jpg, jpeg, png and gif file types allowed.</small>
							<input type="hidden" id="hidden_edit_icon_file" name="hidden_edit_icon_file">
						</div>
					</div>
					<div class="form-group">
						<label for="brief_desc" class="col-sm-4 control-label">Brief Desc</label>
						<div class="col-sm-8">
							<textarea id="edit_brief_desc" name="edit_brief_desc" rows="10" style="width:100%">
							
							</textarea>
						</div>
					</div>
					<div class="form-group">
						<label for="no_lessons" class="col-sm-4 control-label">No. of Lessons</label>
						<div class="col-sm-8">
							<input type="textbox" class="form-control" id="edit_no_lessons" name="edit_no_lessons" placeholder="No. of Lessons">
						</div>
					</div>
				</div>
              <div class="modal-footer">
                <button type="button" class="btn btn-flat btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-flat btn-warning save_now" data-action="edit_draft">Save as draft</button>
				<button type="button" class="btn btn-flat btn-success save_now" data-action="edit_publish">Publish now</button>
				</form>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		
		<div class="modal fade in" id="modal-view">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span></button>
					<h4 class="modal-title">View Course</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p class="loading-message"></p>
						</div>
					</div>
					<div class="row current_course">
						
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-flat btn-default pull-right" data-dismiss="modal">Close</button>
				</div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
		
		
    </section>
    <!-- /.content -->
  </div>
      
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/footer'); ?>
	<script>
		$(document).ready(function() 
			{
				$('#admin_table').DataTable();
				$('#brief_desc, #edit_brief_desc').wysihtml5({
								  toolbar: {
									"font-styles": false,
									"emphasis": true,
									"lists": false,
									"html": false,
									"link": false,
									"image": false,
									"color": false,
									"blockquote": true
								  }
								});
			});
	</script>
	 <?php 
		$csrf = array(
				'name' => $this->security->get_csrf_token_name(),
				'hash' => $this->security->get_csrf_hash()
			);
	?>
	<script>
		$(document).ready(function() 
			{
				$('#admin_table').DataTable();
				
				$('INPUT[type="file"]').change(function () {
					var ext = this.value.match(/\.(.+)$/)[1];
					switch (ext) {
						case 'jpg':
						case 'jpeg':
						case 'png':
						case 'gif':
							$('#uploadButton').attr('disabled', false);
							break;
						default:
							swal('This is not an allowed file type.');
							this.value = '';
					}
				});
				
				$( ".save_now" ).click(function( event ) {
					  
					var publish_status 	= $(this).attr("data-action");
					var course_name 	= $('#course_name').val();
					var english 		= $('#english').val();
					var arabic 			= $('#arabic').val();
					var urdu 			= $('#urdu').val();
					var pashto 			= $('#pashto').val();
					var malayalam 		= $('#malayalam').val();
					var icon_file 		= $('#icon_file').val();
					var brief_desc 		= $('#brief_desc').val();
					var no_lessons 		= $('#no_lessons').val();
					var form 			= $('#add_course_form')[0];
					var data 			= new FormData(form);  
					
					if(course_name == '')
					{	
						swal('Course name should not be empty');
						$('#course_name').addClass("error");
						return false;
					}
					else 
					{
						$('#course_name').addClass("success");
					}
										
					if(no_lessons == '')
					{	
						swal('Please enter the number of lessons in this course.');
						$('#no_lessons').addClass("error");
						return false;
					}
					else 
					{
						$('#no_lessons').addClass("success");
					}
					
					data.append("<?=$csrf['name'];?>", "<?=$csrf['hash'];?>");
					data.append("publish_status", publish_status);
					// $.post( "<?php echo base_url(); ?>admin/student/add", { 
								// staff_name: staff_name, 
								// staff_email: staff_email,
								// staff_cnumber: staff_cnumber,
								// staff_password: staff_password,
								// <?=$csrf['name'];?>: "<?=$csrf['hash'];?>"								
							// }, function(data) {
								
							// $( "#add_form" ).trigger("reset");	
							// swal({title: "Message", text: data, type: 
								// "info"}).then(function(){ 
								   // location.reload();
								   // }
								// );
							// })
							// .fail(function() {
								// swal('Something went wrong. Please check whether you are connected to Internet.');
							// })
					
						$.ajax({
									type: "POST",
									enctype: 'multipart/form-data',
									url: "<?php echo base_url(); ?>admin/course/add",
									data: data,
									processData: false,
									contentType: false,
									cache: false,
									timeout: 600000,
									success: function (data) {
										console.log(data);
										swal({title: "Message", text: data, type: 
										"info"}).then(function(){ 
										   location.reload();
										   });
									},
									error: function (e) {
										
										swal(e.responseText);
										console.log("ERROR : ", e);

									}
								});					
							
					event.preventDefault();
				});
				
				
				$('.delete_now').click(function(){
					
					var delid = $(this).attr("data-id");
					Swal({
					  title: 'Are you sure?',
					  text: "You won't be able to revert this!",
					  type: 'warning',
					  showCancelButton: true,
					  confirmButtonColor: '#3085d6',
					  cancelButtonColor: '#d33',
					  confirmButtonText: 'Yes, delete Course!'
					}).then((result) => {
					  if (result.value) {
						
						$.post( "<?php echo base_url(); ?>admin/course/delete", { 
									id: delid,
									<?=$csrf['name'];?>: "<?=$csrf['hash'];?>"								
								}, function(data) {
							swal({title: "Message", text: data, type: 
								"info"}).then(function(){ 
								   location.reload();
								   }
								);
						})
						.fail(function() {
							swal('Something went wrong. Please check whether you are connected to Internet.');
						})
						
					  }
					})
					
					
				});
				
				
				$('.edit_now').click(function(){
					var etid = $(this).attr("data-id");
					$.post("<?php echo base_url(); ?>admin/course/getcourse", { 
									id: etid,
									<?=$csrf['name'];?>: "<?=$csrf['hash'];?>"							
								}, function(data) {
									
									if(data == 'empty_id')
									{
										swal({title: "Message", text: 'Sorry! We are not able to process student information concerned with this edit', type: 
										"info"}).then(function(){ 
										   location.reload();
										   }
										);
									}
									else 
									{
										$(".edit_form").trigger("reset");
										var obj = JSON.parse(data);
										$('#edit_eid').val(etid);
										$('#edit_course_name').val(obj['0'].course_name);
										$('#hidden_edit_icon_file').val(obj['0'].icon_file);
										//$('#edit_brief_desc').data("wysihtml5").editor.setValue(obj['0'].course_desc);
										$('#edit_brief_desc').val(obj['0'].course_desc);
										$('#edit_no_lessons').val(obj['0'].lesson_no);
										$('#modal-edit').modal('show');
										$('.overlay').hide();
									}
						})
						.fail(function() {
							swal({title: "Message", text: 'Sorry! We are not able to process student information concerned with this edit', type: 
								"info"}).then(function(){ 
								   location.reload();
								   }
								);
						})
				});
				
				$('#submit_edit').click(function(){
					
					var edit_eid = $('#edit_eid').val();
					var edit_name = $('#edit_name').val();
					var edit_email = $('#edit_email').val();
					var edit_cnumber = $('#edit_contact').val();
					var edit_password = $('#edit_password').val();
					 
					if(edit_name == '')
					{	
						swal('Name should not be empty');
						$('#edit_name').addClass("error");
						return false;
					}
					else 
					{
						$('#edit_name').addClass("success");
					}
					
					if(edit_email == '')
					{	
						swal('Email should not be empty');
						$('#edit_email').addClass("error");
						return false;
					}
					else 
					{
						if( !validateEmail(edit_email)) 
							{ 
								swal('Email address not in correct format.');
								$('#edit_email').addClass("error");
								return false;
							}
						else
							{
								$('#edit_email').addClass("success");
							}	
						
					}
					
					if(edit_cnumber == '')
					{	
						swal('Contact number should not be empty');
						$('#edit_cnumber').addClass("error");
						return false;
					}
					else 
					{
						$('#edit_cnumber').addClass("success");
					}
					
					$.post("<?php echo base_url(); ?>admin/student/updatestaff", { 
									id: edit_eid,
									name: edit_name, 
									email: edit_email, 
									staff_number: edit_cnumber, 
									password: edit_password,
									<?=$csrf['name'];?>: '<?=$csrf['hash'];?>'
								}, function(data) {
									
										swal({title: "Message", text: data, type: 
										"info"}).then(function(){ 
										   location.reload();
										   }
										);
						})
						.fail(function() {
							swal({title: "Message", text: 'Sorry! We are not able to process student information concerned with this edit', type: 
								"info"}).then(function(){ 
								   location.reload();
								   }
								);
						})
				});
				
								
				$('.view_courses').on('click', function (e) {
					var view_id = $(this).attr("data-id");
					$('.loading-message').show();
					$('.loading-message').text('Please wait while we load your course details...');
					$('.current_course').html('');
					
					$.post("<?php echo base_url(); ?>admin/course/getcoursebyid", { 
									id: view_id,
									<?=$csrf['name'];?>: '<?=$csrf['hash'];?>'
								}, function(data) 
									{
										var obj = jQuery.parseJSON(data);
										if(obj.status == 'success')
											{
												$('.loading-message').hide();
												$('.current_course').html(obj.html);
											}
										else 
											{
												swal({title: "Message", text: 'Sorry! We are not able to process student information concerned with this edit', type: 
												"info"}).then(function(){ 
												   location.reload();
												   }
												);	
											}											
									})
						.fail(function() {
							swal({title: "Message", text: 'Sorry! We are not able to process student information concerned with this edit', type: 
								"info"}).then(function(){ 
								   location.reload();
								   }
								);
						});
				});
				
				/* Validation Email*/
				function validateEmail($email) {
					  var emailReg = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
					  return emailReg.test( $email );
					}
				
			});
	</script>