<?php
$this->load->view('front/header');
?>
     <!--Menu : Navigation-->
    <nav id="navigtion" class="blockClass fixedNavigation">
        <div class="container">
            <ul>
                <li>
                    <a href="#">My chapters</a>
                </li>
                <li>
                    <a href="#">Help</a>
                </li>
                <li>
                    <a href="#">
                        Quiz
                        <i class="fa fa-caret-down" aria-hidden="true"></i>
                    </a>
                    <ul>
                        <li>
                            <a href="#">Sub Navigtion 1</a>
                        </li>
                        <li>
                            <a href="#">Sub Navigtion 2</a>
                        </li>
                        <li>
                            <a href="#">Sub Navigtion 3</a>
                        </li>
                        <li>
                            <a href="#">Sub Navigtion 4</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <!--Menu : Navigation-->

    <!--Section-->
    <section class="blockClass mainSection">
        <!--Content Wrapper-->
        <div class="blockClass contentWrapper">
            <div class="container">
                <section class="blockClass headerSubSection">
        <div class="container">
           Student Dashboard
        </div>
    </section>
    <!--Section : Header Sub Section-->

    <!--Section : Section Heading-->
    <section class="blockClass sectionSubHeading">
        <div class="container">
            <h3 class="heading">Welcome Wessam</h3>
            <small class="smallFont">To begin your theory E-Class please select the course and click start.</small>
        </div>
		</section>

                <div class="blockClass" style="margin-top: 20px; margin-bottom: 20px">
                    <!--Left Block-->
                    <div class="whiteBlock blockSeprator blockClass">
                        <p class="paraMedium-1">Student Profile</p>
                        <hr />
						<span class="pull-left"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;</span>
                        <p class="paraMedium">Full Name: </p>
						<span>Wessam MHD Amin Araby Al Birouty</span>
                        <hr />
                        <span class="pull-left"><i class="fa fa-file" aria-hidden="true"></i>&nbsp;</span>
                        <p class="paraMedium">Student ID No:</p>
						<span>4564345-8</span>
                        <hr />
						<span class="pull-left"><i class="fa fa-id-card-o" aria-hidden="true"></i>&nbsp;</span>
                        <p class="paraMedium">Emirates ID No:</p>
						<span>784 - 1988 - 4564345-8</span>
						<hr />
                    </div>
					
					<!--Left Block-->

                    <!--Right Block-->
                    <div class="whiteBlock blockSeprator blockClass">
                        <p class="paraMedium-1">Required Courses:</p>
                        <hr />
						<div class="pull-left" style="color:orange; border:10px; border-radius:5px;"><i class="fa fa-taxi  aria-hidden="true"></i></div>
						<p>LIGHT VEHICLE:</p>
						<p class="paraMedium">TRAINING COURSE</p>
                        <hr />
                        
                        <p class="paraMedium">About The course:</p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry›s standard dummy text ever since
						the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only fve centuries, </p>
                        <hr />
						
			             
                        <p class="paraMedium">Course Informations:</p>
						<p class="wrapper"></p>
						<span class="b progressive-bar">
						<span class="progress-bar-fill" style="width:40%; "></span></span>
						<span class="a">8 &nbsp Lessons Required</span>
						<span class="a">2 &nbsp Lessons Completed</span>
						<span class="a">6 &nbsp Lessons Remaining</span>
						<hr />
						<p class="paraMedium">E-Learning Slider:</p>
                        <hr />
						<div class="gallery">
							<img src="front/images/arrows.jpg"  width="100%">
							</div>
							<div class="gallery">
							<img src="front/images/steyaring.jpg"   width="100%" >
							</div>

							<div class="gallery">
							<img src="front/images/Wing-mirror.jpg"  width="100%">
							 </div>

							<div class="gallery">
							<img src="front/images/difficult-condition.jpg"  width="100%" >
							</div>

							<div class="gallery">
							 <img src="front/images/steyaring-2.jpg"  width="100%">
							</div>
							<div class="gallery">
							 <img src="front/images/basics driving.jpg"  width="100%">
							</div>
							<div class="gallery">
							<img src="front/images/inside car.jpg"  width="100%">
							</div>
							<div class="gallery">
							  <img src="front/images/mobile-using.jpg"  width="100%" height="500">
							</div>

													
                    </div>
                    <!--Right Block-->
                </div>
            </div>
        </div>
        <!--Content Wrapper-->
    </section>
    <!--Section-->
<?php
$this->load->view('front/footer');
?>