
    <!--Footer-->
    <footer id="footerType1" class="blockClass">
        <div class="blockClass fContainer">
            <div class="container">
                <span class="fLogoName">
                    <span class="labelIcon labelIconSmall"></span>
                    <strong>E-LEARNING</strong> PLATFORM
                </span>
                <span>v1.0.0 - October 2018</span>
            </div>
        </div>

        <div class="blockClass fContainer">
            <div class="container">
                <div class="fContent">
                    Copyright © 2018 Emirates Driving Company - All rights reserved. Emirates Driving Company is registered trademark
                    <br /> Emirates Driving Company Abu Dhabi, United Arab Emirates - Abu dhabi City, Industrial Musaffah, Blcok
                    M2.
                </div>
                <div class="fContent">
                    <a href="#">Privacy policy</a> |
                    <a href="#">Terms and conditions</a>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer-->
</body>

</html>